calcInput1 = int(input('ENTER FIRST NUMBER'))
calcInput2 = int(input('ENTER SECOND NUMBER'))
calcABout = str(input(' IF YOU WANT TO MULTIPLY WRITE MUL , IF YOU WANT TO ADD WRITE ADD IF YOU WANT TO DIVIDE WRITE DIVIDE IF  YOU WANT TO TAKE SQUARE of 1st numer you enter write sq1 and for the square for 2 number you enter write sq2 IF YOU WANT TO SUBSTRACT WRITE SUBSTRACT WRIOTE ok TO PROCEED'))



# TerminateCALC=True;

# if TerminateCALC == True :
#     del calcDecision
#     del calcABout
#     del calcInput1
#     del calcInput2





if calcABout=='ok' :
    calcDecision = str(input('ENTER WHAT YOU WANT TO DO'))

# TerminateCALC=True;

# if TerminateCALC == True :
#     del calcDecision
#     del calcABout
#     del calcInput1
#     del calcInput2



if calcDecision=='mul' :
    print(calcInput1*calcInput2)

# TerminateCALC=True;

# if TerminateCALC == True :
#     del calcDecision
#     del calcABout
#     del calcInput1
#     del calcInput2


if calcDecision=='add' :
    print(calcInput1+calcInput2)

if calcDecision=='divide' :
    print(calcInput1/calcInput2)


if calcDecision=='substract' :
    print(calcInput1*calcInput2)

if calcDecision=='sq1' :
    print(calcInput1*calcInput1)



if calcDecision=='sq2' :
    print(calcInput2*calcInput2)
2


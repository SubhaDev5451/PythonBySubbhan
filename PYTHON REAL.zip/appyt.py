uopal = ('hell')
print(uopal[:2])